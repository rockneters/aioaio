#!/bin/bash

a=$(cat /usr/local/shadowsocksr/akun.conf | sed 's/### //g')

echo -e ">>_+==================+_<<"
echo -e "||      User SSR        ||"
echo -e ">>_+==================+_<<"
echo -e "\n$a"
echo -e "\nPremium Script Make by Rocknet"
