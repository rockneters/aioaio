#!/bin/bash
red='\e[1;31m'
green='\e[0;32m'
NC='\e[0m'
MYIP=$(wget -qO- icanhazip.com);
echo "Checking VPS"
clear
echo -e ""
echo -e "======================================"
echo -e "${red}[1]${NC} • Change Port Stunnel4"
echo -e "${red}[2]${NC} • Change Port OpenVPN"
echo -e "${red}[3]${NC} • Change Port Wireguard"
echo -e "${red}[4]${NC} • Change Port Vmess"
echo -e "${red}[5]${NC} • Change Port Vless"
echo -e "${red}[6]${NC} • Change Port Trojan"
echo -e "${red}[7]${NC} • Change Port Squid"
echo -e "${red}[8]${NC} • Change Port SSTP"
echo -e "======================================"
echo -e "${red}[x]${NC} • Exit"
echo -e "======================================"
echo -e ""
read -p "${red}Select From Options [1-8 or x] :${NC}" port
echo -e ""
case $port in
1)
port-ssl
;;
2)
port-ovpn
;;
3)
port-wg
;;
4)
port-ws
;;
5)
port-vless
;;
6)
port-tr
;;
7)
port-squid
;;
8)
port-sstp
;;
x)
clear
menu
;;
*)
echo "Please enter an correct number"
;;
esac
